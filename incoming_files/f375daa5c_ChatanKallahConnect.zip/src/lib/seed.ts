// Utility: bootstrap a sample event on first signup so the user has data to play with
import { supabase } from "@/integrations/supabase/client";

export async function seedDemoEvent(ownerId: string) {
  const { data: existing } = await supabase
    .from("events")
    .select("id")
    .eq("owner_id", ownerId)
    .limit(1)
    .maybeSingle();
  if (existing) return existing.id;

  const { data: ev, error } = await supabase
    .from("events")
    .insert({
      owner_id: ownerId,
      bride_name: "נועה",
      groom_name: "איתי",
      hebrew_date: "כ״ב באלול תשפ״ו",
      event_date: "2026-09-03T19:30:00+03:00",
      reception_time: "19:30",
      chuppah_time: "20:30",
      venue_name: "גני האחוזה",
      venue_address: "דרך הים 1, ראשון לציון",
      dress_code: "אלגנט · בגווני שמנת וזהב",
      contact_bride: "052-1234567",
      contact_groom: "054-7654321",
      waze_url: "https://waze.com/ul?q=גני+האחוזה+ראשון+לציון",
      maps_url: "https://maps.google.com/?q=גני+האחוזה+ראשון+לציון",
    })
    .select("id")
    .single();
  if (error || !ev) return null;

  const guests = [
    { name: "משפחת כהן", phone: "050-1111111", invited_count: 4 },
    { name: "שירה ויובל לוי", phone: "052-2222222", invited_count: 2 },
    { name: "דניאל מזרחי", phone: "054-3333333", invited_count: 1 },
    { name: "משפחת אברהמי", phone: "053-4444444", invited_count: 5 },
    { name: "תמר ורון שמש", phone: "058-5555555", invited_count: 2 },
    { name: "אורית פרץ", phone: "050-6666666", invited_count: 1 },
    { name: "משפחת ביטון", phone: "052-7777777", invited_count: 6 },
    { name: "נטע ועידן גולן", phone: "054-8888888", invited_count: 2 },
  ].map((g) => ({ ...g, event_id: ev.id }));

  await supabase.from("guests").insert(guests);
  return ev.id;
}
