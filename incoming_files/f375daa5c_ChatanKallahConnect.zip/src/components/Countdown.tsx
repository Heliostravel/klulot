import { useCountdown } from "@/hooks/useCountdown";

const Box = ({ value, label }: { value: number; label: string }) => (
  <div className="flex flex-col items-center">
    <div className="glass-card w-16 sm:w-20 h-16 sm:h-20 flex items-center justify-center">
      <span className="font-display text-3xl sm:text-4xl text-primary-deep tabular-nums">
        {String(value).padStart(2, "0")}
      </span>
    </div>
    <span className="mt-2 text-xs sm:text-sm text-muted-foreground tracking-wide">{label}</span>
  </div>
);

export const Countdown = ({ target }: { target: string }) => {
  const { days, hours, minutes, seconds } = useCountdown(target);
  return (
    <div className="flex items-center justify-center gap-3 sm:gap-5" dir="ltr">
      <Box value={seconds} label="שניות" />
      <Box value={minutes} label="דקות" />
      <Box value={hours} label="שעות" />
      <Box value={days} label="ימים" />
    </div>
  );
};
