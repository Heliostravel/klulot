import { MessageCircle } from "lucide-react";

export const WhatsAppFab = ({ phone = "972521234567" }: { phone?: string }) => (
  <a
    href={`https://wa.me/${phone}`}
    target="_blank"
    rel="noopener noreferrer"
    aria-label="צרו קשר ב-WhatsApp"
    className="fixed bottom-5 left-5 z-40 h-14 w-14 rounded-full bg-gradient-gold shadow-elegant flex items-center justify-center text-primary-foreground hover:scale-110 transition-transform animate-float"
  >
    <MessageCircle className="h-7 w-7" />
  </a>
);
