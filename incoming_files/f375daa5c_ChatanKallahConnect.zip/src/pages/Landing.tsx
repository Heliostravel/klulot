import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Heart, Send, BarChart3, Sparkles, Smartphone, ShieldCheck } from "lucide-react";
import heroImg from "@/assets/wedding-hero.jpg";

const Feature = ({ icon: Icon, title, desc }: any) => (
  <div className="glass-card p-6 text-center animate-fade-up">
    <div className="mx-auto h-12 w-12 rounded-full bg-gradient-gold flex items-center justify-center mb-4 shadow-glow">
      <Icon className="h-6 w-6 text-primary-foreground" />
    </div>
    <h3 className="font-display text-xl mb-2 text-primary-deep">{title}</h3>
    <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
  </div>
);

const Landing = () => {
  return (
    <main className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="container max-w-6xl pt-20 pb-16 grid md:grid-cols-2 gap-12 items-center">
          <div className="text-center md:text-right space-y-6 animate-fade-up">
            <p className="font-script text-2xl text-primary">כלולות · Klulot</p>
            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl leading-tight text-primary-deep">
              ההזמנה הדיגיטלית
              <br />
              <span className="text-gradient-gold">היפה ביותר</span>
              <br />
              לחתונה שלכם
            </h1>
            <div className="divider-gold"><Heart className="h-4 w-4" /></div>
            <p className="text-lg text-muted-foreground max-w-md mx-auto md:mx-0">
              שלחו ב-WhatsApp הזמנה אישית לכל אורח, עקבו אחרי אישורי הגעה בזמן אמת,
              והשאירו רושם של חתונת חלום.
            </p>
            <div className="flex flex-wrap gap-3 justify-center md:justify-start">
              <Button asChild variant="hero" size="xl">
                <Link to="/onboarding">צרו את החתונה שלכם</Link>
              </Button>
              <Button asChild variant="outlineGold" size="xl">
                <Link to="/login">לדשבורד שלי</Link>
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              ללא הורדות · ללא אפליקציה · עובד מצוין במובייל
            </p>
          </div>
          <div className="relative animate-scale-in delay-200">
            <div className="absolute inset-0 bg-gradient-gold opacity-20 blur-3xl rounded-full" />
            <img
              src={heroImg}
              alt="הזמנת חתונה אלגנטית"
              width={1280}
              height={1600}
              className="relative rounded-3xl shadow-elegant w-full max-w-md mx-auto object-cover"
            />
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container max-w-6xl py-20">
        <div className="text-center mb-14">
          <div className="divider-gold mb-4"><Sparkles className="h-4 w-4" /></div>
          <h2 className="font-display text-4xl sm:text-5xl text-primary-deep">כל מה שצריך, במקום אחד</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <Feature icon={Send} title="שליחה ב-WhatsApp" desc="לינק אישי לכל אורח עם מעקב פתיחות אוטומטי" />
          <Feature icon={BarChart3} title="דשבורד חכם" desc="כל הסטטיסטיקות בזמן אמת: מי אישר, מי פתח, כמה מגיעים" />
          <Feature icon={Smartphone} title="מובייל-פירסט" desc="טעינה מהירה במיוחד, מותאם בצורה מושלמת לכל מסך" />
          <Feature icon={Heart} title="עיצוב יוקרתי" desc="טיפוגרפיה רומנטית, פלטה של זהב ושמנת, אנימציות עדינות" />
          <Feature icon={ShieldCheck} title="פרטיות מלאה" desc="הנתונים שלכם מאובטחים. רק לכם יש גישה לדשבורד" />
          <Feature icon={Sparkles} title="קל לעדכן" desc="האורחים יכולים לשנות תשובה בכל רגע מאותו הלינק" />
        </div>
      </section>

      {/* CTA */}
      <section className="container max-w-3xl py-16">
        <div className="glass-card p-10 text-center bg-gradient-soft">
          <h2 className="font-display text-3xl sm:text-4xl text-primary-deep mb-4">
            מוכנים להתחיל?
          </h2>
          <p className="text-muted-foreground mb-6">הקמת החתונה לוקחת פחות מ-5 דקות</p>
          <Button asChild variant="hero" size="xl">
            <Link to="/onboarding">צרו אירוע חדש</Link>
          </Button>
        </div>
      </section>

      <footer className="container py-10 text-center text-sm text-muted-foreground">
        <p>כלולות · עיצוב חתונות דיגיטלי · נוצר באהבה</p>
        <Link to="/login" className="text-primary hover:underline mt-2 inline-block">כניסה לדשבורד הזוג</Link>
      </footer>
    </main>
  );
};

export default Landing;
