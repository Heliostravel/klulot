
-- Profiles
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
create policy "users view own profile" on public.profiles for select using (auth.uid() = id);
create policy "users update own profile" on public.profiles for update using (auth.uid() = id);
create policy "users insert own profile" on public.profiles for insert with check (auth.uid() = id);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, display_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'display_name', new.email));
  return new;
end; $$;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Events
create table public.events (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  bride_name text not null,
  groom_name text not null,
  hebrew_date text,
  event_date timestamptz not null,
  reception_time text,
  chuppah_time text,
  venue_name text,
  venue_address text,
  dress_code text,
  contact_bride text,
  contact_groom text,
  waze_url text,
  maps_url text,
  hero_image_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.events enable row level security;
create policy "owner manages events" on public.events for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "public reads event details" on public.events for select using (true);

-- RSVP status enum
create type public.rsvp_status as enum ('pending','attending','declined','maybe');

-- Guests
create table public.guests (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  name text not null,
  phone text,
  invited_count int not null default 1,
  status public.rsvp_status not null default 'pending',
  attending_count int,
  dietary text,
  blessing text,
  opened boolean not null default false,
  opened_at timestamptz,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
alter table public.guests enable row level security;
-- Owner of event can manage
create policy "owner manages guests" on public.guests for all
  using (exists (select 1 from public.events e where e.id = guests.event_id and e.owner_id = auth.uid()))
  with check (exists (select 1 from public.events e where e.id = guests.event_id and e.owner_id = auth.uid()));
-- Anyone with the link (knowing the guest id) can read & update their own RSVP
create policy "public reads guest by id" on public.guests for select using (true);
create policy "public updates guest rsvp" on public.guests for update using (true) with check (true);

-- Invitation opens analytics
create table public.invitation_opens (
  id uuid primary key default gen_random_uuid(),
  guest_id uuid not null references public.guests(id) on delete cascade,
  event_id uuid not null references public.events(id) on delete cascade,
  opened_at timestamptz not null default now(),
  user_agent text
);
alter table public.invitation_opens enable row level security;
create policy "public inserts opens" on public.invitation_opens for insert with check (true);
create policy "owner reads opens" on public.invitation_opens for select
  using (exists (select 1 from public.events e where e.id = invitation_opens.event_id and e.owner_id = auth.uid()));

-- updated_at trigger
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;
create trigger events_touch before update on public.events for each row execute function public.touch_updated_at();
create trigger guests_touch before update on public.guests for each row execute function public.touch_updated_at();
