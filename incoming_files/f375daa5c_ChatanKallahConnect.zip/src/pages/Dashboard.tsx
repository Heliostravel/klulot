import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Send, Download, Eye, Users, Check, X, Bell, LogOut, Plus, Copy, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, PieChart, Pie, Cell, Legend } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

type Status = "pending" | "attending" | "declined" | "maybe";
const statusLabels: Record<Status, string> = { attending: "מגיעים", declined: "לא מגיעים", maybe: "מתלבטים", pending: "ממתינים" };
const statusColor: Record<Status, string> = {
  attending: "bg-primary/15 text-primary-deep border-primary/30",
  declined: "bg-destructive/10 text-destructive border-destructive/30",
  maybe: "bg-accent text-accent-foreground border-accent",
  pending: "bg-muted text-muted-foreground border-border",
};

const Stat = ({ label, value, icon: Icon, accent }: any) => (
  <Card className="p-5 glass-card">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="font-display text-3xl text-primary-deep mt-1">{value}</p>
      </div>
      <div className={`h-11 w-11 rounded-full flex items-center justify-center ${accent}`}>
        <Icon className="h-5 w-5 text-primary-foreground" />
      </div>
    </div>
  </Card>
);

const Dashboard = () => {
  const { user, loading: authLoading, signOut } = useAuth();
  const navigate = useNavigate();
  const [event, setEvent] = useState<any>(null);
  const [guests, setGuests] = useState<any[]>([]);
  const [opens, setOpens] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [newGuest, setNewGuest] = useState({ name: "", phone: "", invited_count: 2 });

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      setLoading(true);
      const { data: ev } = await supabase.from("events").select("*").eq("owner_id", user.id).order("created_at", { ascending: false }).limit(1).maybeSingle();
      if (!ev) { setLoading(false); return; }
      setEvent(ev);
      const [{ data: g }, { data: o }] = await Promise.all([
        supabase.from("guests").select("*").eq("event_id", ev.id).order("created_at"),
        supabase.from("invitation_opens").select("opened_at").eq("event_id", ev.id),
      ]);
      setGuests(g ?? []);
      setOpens(o ?? []);
      setLoading(false);
    })();
  }, [user]);

  const stats = useMemo(() => {
    const total = guests.length;
    const opened = guests.filter((g) => g.opened).length;
    const attending = guests.filter((g) => g.status === "attending").length;
    const declined = guests.filter((g) => g.status === "declined").length;
    const maybe = guests.filter((g) => g.status === "maybe").length;
    const pending = guests.filter((g) => g.status === "pending").length;
    const attendingCount = guests.filter((g) => g.status === "attending").reduce((s, g) => s + (g.attending_count ?? 0), 0);
    return { total, opened, attending, declined, maybe, pending, attendingCount };
  }, [guests]);

  const opensByDay = useMemo(() => {
    const days = ["א׳", "ב׳", "ג׳", "ד׳", "ה׳", "ו׳", "ש׳"];
    const counts = Array(7).fill(0);
    opens.forEach((o) => { counts[new Date(o.opened_at).getDay()]++; });
    return days.map((day, i) => ({ day, opens: counts[i] }));
  }, [opens]);

  const pieData = [
    { name: statusLabels.attending, value: stats.attending, color: "hsl(36 60% 55%)" },
    { name: statusLabels.declined, value: stats.declined, color: "hsl(0 60% 60%)" },
    { name: statusLabels.maybe, value: stats.maybe, color: "hsl(42 75% 68%)" },
    { name: statusLabels.pending, value: stats.pending, color: "hsl(36 15% 70%)" },
  ];

  const filtered = guests.filter((g) => g.name.includes(search) || (g.phone ?? "").includes(search));

  const exportCSV = () => {
    const headers = ["שם", "טלפון", "הוזמנו", "סטטוס", "מגיעים", "תזונה", "ברכה"];
    const rows = guests.map((g) => [g.name, g.phone ?? "", g.invited_count, statusLabels[g.status as Status], g.attending_count ?? "", g.dietary ?? "", (g.blessing ?? "").replace(/,/g, " ")]);
    const csv = "\uFEFF" + [headers, ...rows].map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "guests.csv"; a.click();
    URL.revokeObjectURL(url);
    toast.success("הקובץ ירד למחשב 💛");
  };

  const sendReminder = () => {
    const pendingGuests = guests.filter((g) => g.status === "pending");
    const url = (g: any) => `${window.location.origin}/invite/${g.id}`;
    const txt = pendingGuests.map((g) => `${g.name}: ${url(g)}`).join("\n");
    navigator.clipboard.writeText(txt);
    toast.success(`הועתקו ${pendingGuests.length} לינקים לתזכורת 💛`);
  };

  const copyLink = (id: string) => {
    navigator.clipboard.writeText(`${window.location.origin}/invite/${id}`);
    toast.success("הלינק הועתק");
  };

  const addGuest = async () => {
    if (!event || !newGuest.name) return;
    const { data, error } = await supabase.from("guests").insert({ ...newGuest, event_id: event.id }).select().single();
    if (error) { toast.error(error.message); return; }
    setGuests([...guests, data]);
    setShowAdd(false);
    setNewGuest({ name: "", phone: "", invited_count: 2 });
    toast.success("האורח נוסף 💛");
  };

  if (authLoading || loading) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  }

  if (!event) {
    return (
      <main className="min-h-screen flex items-center justify-center p-4">
        <Card className="glass-card p-10 max-w-md text-center">
          <h2 className="font-display text-2xl text-primary-deep mb-3">בואו ניצור את החתונה שלכם</h2>
          <p className="text-muted-foreground mb-6">עדיין אין לכם אירוע. אונבורדינג קצר ואתם מוכנים.</p>
          <Button variant="hero" asChild><Link to="/onboarding">בואו נתחיל</Link></Button>
        </Card>
      </main>
    );
  }

  return (
    <main className="min-h-screen">
      <header className="border-b border-border bg-card/60 backdrop-blur-sm sticky top-0 z-30">
        <div className="container max-w-7xl py-4 flex items-center justify-between flex-wrap gap-3">
          <div>
            <p className="font-script text-lg text-primary leading-none">כלולות</p>
            <h1 className="font-display text-xl text-primary-deep">דשבורד · {event.bride_name} & {event.groom_name}</h1>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="outlineGold" size="sm" onClick={() => setShowAdd(true)}><Plus className="h-4 w-4 ml-1" />אורח</Button>
            <Button variant="outlineGold" size="sm" onClick={sendReminder}><Bell className="h-4 w-4 ml-1" />תזכורת</Button>
            <Button variant="outlineGold" size="sm" onClick={exportCSV}><Download className="h-4 w-4 ml-1" />ייצוא</Button>
            <Button variant="ghost" size="sm" onClick={async () => { await signOut(); navigate("/"); }}><LogOut className="h-4 w-4" /></Button>
          </div>
        </div>
      </header>

      <div className="container max-w-7xl py-8 space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          <Stat label="הוזמנו" value={stats.total} icon={Send} accent="bg-primary-deep" />
          <Stat label="פתחו הזמנה" value={stats.opened} icon={Eye} accent="bg-primary" />
          <Stat label="אישרו" value={stats.attending} icon={Check} accent="bg-gradient-gold" />
          <Stat label="לא מגיעים" value={stats.declined} icon={X} accent="bg-destructive" />
          <Stat label="סה״כ מגיעים" value={stats.attendingCount} icon={Users} accent="bg-primary-deep" />
        </div>

        <div className="grid lg:grid-cols-2 gap-4">
          <Card className="glass-card p-5">
            <h3 className="font-display text-lg text-primary-deep mb-4">פתיחות לפי יום</h3>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={opensByDay}>
                <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12 }} />
                <Bar dataKey="opens" fill="hsl(var(--primary))" radius={[8,8,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
          <Card className="glass-card p-5">
            <h3 className="font-display text-lg text-primary-deep mb-4">פילוח אישורי הגעה</h3>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={85} paddingAngle={2}>
                  {pieData.map((d, i) => <Cell key={i} fill={d.color} />)}
                </Pie>
                <Legend />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </div>

        <Card className="glass-card p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <h3 className="font-display text-xl text-primary-deep">רשימת אורחים</h3>
            <Input placeholder="חיפוש לפי שם / טלפון..." value={search} onChange={(e) => setSearch(e.target.value)} className="max-w-xs" />
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">שם</TableHead>
                  <TableHead className="text-right">טלפון</TableHead>
                  <TableHead className="text-right">הוזמנו</TableHead>
                  <TableHead className="text-right">סטטוס</TableHead>
                  <TableHead className="text-right">מגיעים</TableHead>
                  <TableHead className="text-right">נפתח</TableHead>
                  <TableHead className="text-right">עודכן</TableHead>
                  <TableHead className="text-right">לינק</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((g) => (
                  <TableRow key={g.id}>
                    <TableCell className="font-medium">{g.name}</TableCell>
                    <TableCell className="text-muted-foreground" dir="ltr">{g.phone ?? "—"}</TableCell>
                    <TableCell>{g.invited_count}</TableCell>
                    <TableCell><Badge variant="outline" className={statusColor[g.status as Status]}>{statusLabels[g.status as Status]}</Badge></TableCell>
                    <TableCell>{g.attending_count ?? "—"}</TableCell>
                    <TableCell>{g.opened ? <Check className="h-4 w-4 text-primary" /> : <span className="text-muted-foreground">—</span>}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{g.updated_at ? new Date(g.updated_at).toLocaleString("he-IL") : "—"}</TableCell>
                    <TableCell>
                      <Button size="sm" variant="ghost" onClick={() => copyLink(g.id)}><Copy className="h-4 w-4" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>

      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent>
          <DialogHeader><DialogTitle>הוספת אורח</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>שם</Label><Input value={newGuest.name} onChange={(e) => setNewGuest({ ...newGuest, name: e.target.value })} /></div>
            <div><Label>טלפון</Label><Input value={newGuest.phone} onChange={(e) => setNewGuest({ ...newGuest, phone: e.target.value })} dir="ltr" /></div>
            <div><Label>כמה הוזמנו</Label><Input type="number" min={1} value={newGuest.invited_count} onChange={(e) => setNewGuest({ ...newGuest, invited_count: Number(e.target.value) })} /></div>
          </div>
          <DialogFooter><Button variant="hero" onClick={addGuest}>הוספה</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  );
};

export default Dashboard;
