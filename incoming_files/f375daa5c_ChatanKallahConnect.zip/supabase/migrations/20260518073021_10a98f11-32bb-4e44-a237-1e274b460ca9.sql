
drop policy if exists "public updates guest rsvp" on public.guests;
drop policy if exists "public inserts opens" on public.invitation_opens;

create or replace function public.submit_rsvp(
  p_guest_id uuid,
  p_status public.rsvp_status,
  p_attending_count int default null,
  p_dietary text default null,
  p_blessing text default null
) returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.guests
     set status = p_status,
         attending_count = case when p_status = 'attending' then coalesce(p_attending_count, attending_count) else null end,
         dietary = coalesce(p_dietary, dietary),
         blessing = coalesce(p_blessing, blessing),
         updated_at = now()
   where id = p_guest_id;
end;
$$;

create or replace function public.track_invitation_open(
  p_guest_id uuid,
  p_user_agent text default null
) returns void
language plpgsql
security definer
set search_path = public
as $$
declare v_event uuid;
begin
  select event_id into v_event from public.guests where id = p_guest_id;
  if v_event is null then return; end if;
  insert into public.invitation_opens (guest_id, event_id, user_agent)
  values (p_guest_id, v_event, p_user_agent);
  update public.guests set opened = true, opened_at = coalesce(opened_at, now()) where id = p_guest_id;
end;
$$;

revoke execute on function public.submit_rsvp(uuid, public.rsvp_status, int, text, text) from public;
grant execute on function public.submit_rsvp(uuid, public.rsvp_status, int, text, text) to anon, authenticated;

revoke execute on function public.track_invitation_open(uuid, text) from public;
grant execute on function public.track_invitation_open(uuid, text) to anon, authenticated;
