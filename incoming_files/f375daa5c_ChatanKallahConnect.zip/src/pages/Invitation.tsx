import { useParams, Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Heart, MapPin, Navigation, Phone, Calendar, Clock, Sparkles, Check, X, HelpCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Countdown } from "@/components/Countdown";
import { WhatsAppFab } from "@/components/WhatsAppFab";
import { MusicToggle } from "@/components/MusicToggle";
import { supabase } from "@/integrations/supabase/client";
import heroImg from "@/assets/wedding-hero.jpg";
import g1 from "@/assets/gallery-1.jpg";
import g2 from "@/assets/gallery-2.jpg";
import g3 from "@/assets/gallery-3.jpg";

type Status = "pending" | "attending" | "declined" | "maybe";

const Invitation = () => {
  const { guestId } = useParams();
  const [loading, setLoading] = useState(true);
  const [guest, setGuest] = useState<any>(null);
  const [event, setEvent] = useState<any>(null);
  const [status, setStatus] = useState<Status>("pending");
  const [count, setCount] = useState(1);
  const [dietary, setDietary] = useState("");
  const [blessing, setBlessing] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!guestId) return;
    (async () => {
      const { data: g } = await supabase.from("guests").select("*").eq("id", guestId).maybeSingle();
      if (!g) { setLoading(false); return; }
      setGuest(g);
      setStatus(g.status as Status);
      setCount(g.attending_count ?? g.invited_count);
      setDietary(g.dietary ?? "");
      setBlessing(g.blessing ?? "");
      const { data: ev } = await supabase.from("events").select("*").eq("id", g.event_id).maybeSingle();
      setEvent(ev);
      setLoading(false);
      // Track open
      supabase.rpc("track_invitation_open", { p_guest_id: guestId, p_user_agent: navigator.userAgent });
    })();
  }, [guestId]);

  const submit = async (s: Status) => {
    if (!guest) return;
    setStatus(s);
    setSaving(true);
    const { error } = await supabase.rpc("submit_rsvp", {
      p_guest_id: guest.id, p_status: s,
      p_attending_count: s === "attending" ? count : null,
      p_dietary: dietary || null, p_blessing: blessing || null,
    });
    setSaving(false);
    if (error) { toast.error("שגיאה בעדכון"); return; }
    toast.success(s === "attending" ? "כיף שתבואו! 💛" : s === "declined" ? "תודה שהשבתם — נתגעגע!" : "תודה! תוכלו לעדכן בכל רגע");
  };

  const saveDetails = async () => {
    if (!guest) return;
    setSaving(true);
    const { error } = await supabase.rpc("submit_rsvp", {
      p_guest_id: guest.id, p_status: "attending",
      p_attending_count: count, p_dietary: dietary || null, p_blessing: blessing || null,
    });
    setSaving(false);
    if (error) { toast.error("שגיאה"); return; }
    toast.success("הפרטים נשמרו 💛");
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;

  if (!guest || !event) {
    return (
      <main className="min-h-screen flex items-center justify-center p-4 text-center">
        <div>
          <h1 className="font-display text-3xl text-primary-deep mb-3">ההזמנה לא נמצאה</h1>
          <p className="text-muted-foreground mb-6">ייתכן שהלינק שגוי או שההזמנה הוסרה.</p>
          <Button asChild variant="hero"><Link to="/">חזרה לדף הבית</Link></Button>
        </div>
      </main>
    );
  }

  const eventDate = new Date(event.event_date);
  const dateStr = eventDate.toLocaleDateString("he-IL", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  const submitted = status !== "pending";

  return (
    <main className="min-h-screen pb-32">
      <MusicToggle />
      <WhatsAppFab phone={(event.contact_bride ?? "972521234567").replace(/\D/g, "")} />

      <section className="relative px-4 pt-10 pb-8 max-w-xl mx-auto">
        <div className="text-center mb-4 animate-fade-up">
          <p className="font-script text-xl text-primary">שלום {guest.name} 💛</p>
          <p className="text-sm text-muted-foreground mt-1">בכבוד רב הנכם מוזמנים לחתונה של</p>
        </div>

        <div className="relative rounded-3xl overflow-hidden shadow-elegant animate-scale-in">
          <img src={event.hero_image_url ?? heroImg} alt={`הזמנה לחתונה של ${event.bride_name} ו${event.groom_name}`} width={1280} height={1600} className="w-full object-cover aspect-[4/5]" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background/95" />
          <div className="absolute bottom-0 inset-x-0 p-6 text-center">
            <p className="font-script text-2xl text-primary-deep mb-1">חתונת חלום</p>
            <h1 className="font-display text-4xl sm:text-5xl text-primary-deep">
              {event.bride_name} <span className="text-gradient-gold">&</span> {event.groom_name}
            </h1>
            <div className="divider-gold mt-3"><Heart className="h-4 w-4" /></div>
            {event.hebrew_date && <p className="text-sm text-muted-foreground mt-2">{event.hebrew_date}</p>}
          </div>
        </div>
      </section>

      <section className="px-4 max-w-xl mx-auto mb-10">
        <div className="glass-card p-6 text-center animate-fade-up delay-200">
          <p className="text-sm text-muted-foreground mb-4">הספירה לאחור החלה</p>
          <Countdown target={event.event_date} />
        </div>
      </section>

      <section className="px-4 max-w-xl mx-auto mb-10 space-y-3 animate-fade-up delay-300">
        <div className="glass-card p-5 flex items-start gap-4">
          <Calendar className="h-5 w-5 text-primary mt-1 shrink-0" />
          <div><p className="font-medium">{dateStr}</p>{event.hebrew_date && <p className="text-sm text-muted-foreground">{event.hebrew_date}</p>}</div>
        </div>
        {(event.reception_time || event.chuppah_time) && (
          <div className="glass-card p-5 flex items-start gap-4">
            <Clock className="h-5 w-5 text-primary mt-1 shrink-0" />
            <div>
              {event.reception_time && <p className="font-medium">קבלת פנים: {event.reception_time}</p>}
              {event.chuppah_time && <p className="text-sm text-muted-foreground">חופה: {event.chuppah_time}</p>}
            </div>
          </div>
        )}
        {event.venue_name && (
          <div className="glass-card p-5">
            <div className="flex items-start gap-4 mb-3">
              <MapPin className="h-5 w-5 text-primary mt-1 shrink-0" />
              <div><p className="font-medium">{event.venue_name}</p>{event.venue_address && <p className="text-sm text-muted-foreground">{event.venue_address}</p>}</div>
            </div>
            <div className="flex gap-2">
              {event.waze_url && <Button asChild variant="outlineGold" size="sm" className="flex-1"><a href={event.waze_url} target="_blank" rel="noopener noreferrer"><Navigation className="h-4 w-4 ml-1" />Waze</a></Button>}
              {event.maps_url && <Button asChild variant="outlineGold" size="sm" className="flex-1"><a href={event.maps_url} target="_blank" rel="noopener noreferrer"><MapPin className="h-4 w-4 ml-1" />Maps</a></Button>}
            </div>
          </div>
        )}
        {event.dress_code && (
          <div className="glass-card p-5 flex items-start gap-4">
            <Sparkles className="h-5 w-5 text-primary mt-1 shrink-0" />
            <div><p className="font-medium">קוד לבוש</p><p className="text-sm text-muted-foreground">{event.dress_code}</p></div>
          </div>
        )}
        {(event.contact_bride || event.contact_groom) && (
          <div className="glass-card p-5">
            <div className="flex items-center gap-4 mb-2"><Phone className="h-5 w-5 text-primary shrink-0" /><p className="font-medium">לבירורים</p></div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              {event.contact_bride && <a href={`tel:${event.contact_bride}`} className="text-muted-foreground hover:text-primary">{event.bride_name} · {event.contact_bride}</a>}
              {event.contact_groom && <a href={`tel:${event.contact_groom}`} className="text-muted-foreground hover:text-primary">{event.groom_name} · {event.contact_groom}</a>}
            </div>
          </div>
        )}
      </section>

      <section className="px-4 max-w-xl mx-auto mb-10">
        <div className="glass-card p-6 bg-gradient-soft animate-fade-up">
          <div className="text-center mb-5">
            <h2 className="font-display text-3xl text-primary-deep">אישור הגעה</h2>
            <p className="text-sm text-muted-foreground mt-1">הוזמנתם {guest.invited_count} אורחים. נשמח לדעת בקרוב 💛</p>
          </div>
          <div className="grid grid-cols-3 gap-2 mb-5">
            <Button onClick={() => submit("attending")} variant={status === "attending" ? "hero" : "outlineGold"} className="flex-col h-auto py-3" disabled={saving}>
              <Check className="h-5 w-5 mb-1" /><span className="text-xs">מגיעים</span>
            </Button>
            <Button onClick={() => submit("maybe")} variant={status === "maybe" ? "hero" : "outlineGold"} className="flex-col h-auto py-3" disabled={saving}>
              <HelpCircle className="h-5 w-5 mb-1" /><span className="text-xs">מתלבטים</span>
            </Button>
            <Button onClick={() => submit("declined")} variant={status === "declined" ? "hero" : "outlineGold"} className="flex-col h-auto py-3" disabled={saving}>
              <X className="h-5 w-5 mb-1" /><span className="text-xs">לא מגיעים</span>
            </Button>
          </div>

          {submitted && status === "attending" && (
            <div className="space-y-4 animate-fade-up">
              <div><Label htmlFor="count">כמה תהיו?</Label><Input id="count" type="number" min={1} max={guest.invited_count} value={count} onChange={(e) => setCount(Number(e.target.value))} className="mt-1" /></div>
              <div><Label htmlFor="diet">הערות תזונה (אופציונלי)</Label><Input id="diet" placeholder="צמחוני, ללא גלוטן..." value={dietary} onChange={(e) => setDietary(e.target.value)} className="mt-1" /></div>
              <div><Label htmlFor="bless">ברכה לזוג (אופציונלי)</Label><Textarea id="bless" placeholder="כתבו משהו חמוד..." value={blessing} onChange={(e) => setBlessing(e.target.value)} className="mt-1" rows={3} /></div>
              <Button variant="hero" className="w-full" onClick={saveDetails} disabled={saving}>{saving ? "שומר..." : "שמירת פרטים"}</Button>
            </div>
          )}

          <p className="text-xs text-center text-muted-foreground mt-4">ניתן לעדכן את התשובה בכל רגע מאותו הלינק</p>
        </div>
      </section>

      <section className="px-4 max-w-xl mx-auto mb-10">
        <h2 className="font-display text-2xl text-center text-primary-deep mb-4">רגעים</h2>
        <div className="grid grid-cols-3 gap-2">
          {[g1, g2, g3].map((src, i) => (
            <img key={i} src={src} alt={`גלריה ${i+1}`} loading="lazy" width={1024} height={1024} className="aspect-square object-cover rounded-xl shadow-soft hover:scale-105 transition-transform" />
          ))}
        </div>
      </section>

      <p className="text-center text-xs text-muted-foreground font-script">באהבה, {event.bride_name} & {event.groom_name}</p>
      <div className="text-center mt-6"><Link to="/" className="text-xs text-primary hover:underline">כלולות · צרו את ההזמנה שלכם</Link></div>
    </main>
  );
};

export default Invitation;
