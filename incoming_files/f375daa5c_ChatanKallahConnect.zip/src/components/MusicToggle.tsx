import { useState, useRef, useEffect } from "react";
import { Music2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";

export const MusicToggle = () => {
  const [playing, setPlaying] = useState(false);
  const ref = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    ref.current = new Audio(
      "https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a73467.mp3?filename=romantic-piano-loop-25419.mp3"
    );
    ref.current.loop = true;
    ref.current.volume = 0.3;
    return () => { ref.current?.pause(); };
  }, []);

  const toggle = () => {
    if (!ref.current) return;
    if (playing) ref.current.pause();
    else ref.current.play().catch(() => {});
    setPlaying(!playing);
  };

  return (
    <Button
      onClick={toggle}
      variant="outline"
      size="icon"
      className="fixed top-5 left-5 z-40 rounded-full border-primary/30 bg-card/80 backdrop-blur-sm"
      aria-label={playing ? "השתק מוזיקה" : "הפעל מוזיקה"}
    >
      {playing ? <Music2 className="h-4 w-4 text-primary" /> : <VolumeX className="h-4 w-4 text-muted-foreground" />}
    </Button>
  );
};
