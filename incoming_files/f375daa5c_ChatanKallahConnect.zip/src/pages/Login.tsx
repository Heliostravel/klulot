import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Heart } from "lucide-react";
import { toast } from "sonner";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/contexts/AuthContext";
import { seedDemoEvent } from "@/lib/seed";

const Login = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) navigate("/dashboard");
  }, [user, navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email, password,
          options: { emailRedirectTo: `${window.location.origin}/dashboard`, data: { display_name: name } },
        });
        if (error) throw error;
        if (data.user) await seedDemoEvent(data.user.id);
        toast.success("נרשמתם בהצלחה 💛");
        navigate("/dashboard");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("ברוכים השבים 💛");
        navigate("/dashboard");
      }
    } catch (err: any) {
      toast.error(err.message || "שגיאה");
    } finally { setLoading(false); }
  };

  const google = async () => {
    setLoading(true);
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: `${window.location.origin}/dashboard` });
    if (r.error) { toast.error("שגיאה בכניסה עם Google"); setLoading(false); return; }
    if (r.redirected) return;
    navigate("/dashboard");
  };

  return (
    <main className="min-h-screen flex items-center justify-center p-4">
      <Card className="glass-card p-8 w-full max-w-md animate-scale-in">
        <div className="text-center mb-6">
          <div className="mx-auto h-14 w-14 rounded-full bg-gradient-gold flex items-center justify-center shadow-glow mb-3">
            <Heart className="h-6 w-6 text-primary-foreground" />
          </div>
          <h1 className="font-display text-3xl text-primary-deep">
            {mode === "signin" ? "כניסה לדשבורד" : "יצירת חשבון חדש"}
          </h1>
          <p className="text-sm text-muted-foreground mt-2">נהלו את ההזמנות והאישורים בקלות</p>
        </div>

        <Button variant="outlineGold" className="w-full mb-4" onClick={google} disabled={loading}>
          <svg className="h-4 w-4 ml-2" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
          המשך עם Google
        </Button>
        <div className="divider-gold text-xs mb-4">או</div>

        <form onSubmit={submit} className="space-y-4">
          {mode === "signup" && (
            <div>
              <Label htmlFor="name">שם מלא</Label>
              <Input id="name" required value={name} onChange={(e) => setName(e.target.value)} className="mt-1" />
            </div>
          )}
          <div>
            <Label htmlFor="email">אימייל</Label>
            <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1" dir="ltr" />
          </div>
          <div>
            <Label htmlFor="pass">סיסמה</Label>
            <Input id="pass" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} className="mt-1" dir="ltr" />
          </div>
          <Button type="submit" variant="hero" className="w-full" disabled={loading}>
            {loading ? "רגע..." : mode === "signin" ? "כניסה" : "הרשמה"}
          </Button>
        </form>

        <p className="text-center text-xs text-muted-foreground mt-6">
          {mode === "signin" ? (
            <>אין לכם חשבון? <button onClick={() => setMode("signup")} className="text-primary hover:underline">צרו חשבון</button></>
          ) : (
            <>כבר רשומים? <button onClick={() => setMode("signin")} className="text-primary hover:underline">כניסה</button></>
          )}
        </p>
        <p className="text-center text-xs text-muted-foreground mt-2">
          <Link to="/" className="hover:underline">חזרה לדף הבית</Link>
        </p>
      </Card>
    </main>
  );
};

export default Login;
