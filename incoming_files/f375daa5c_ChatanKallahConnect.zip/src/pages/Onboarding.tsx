import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { Heart, ArrowRight, ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const steps = ["הזוג", "האירוע", "המקום", "סיום"];

const Onboarding = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    bride_name: "", groom_name: "", event_date: "", reception_time: "19:30",
    chuppah_time: "20:30", dress_code: "", venue_name: "", venue_address: "", contact_bride: "",
  });
  const set = (k: string, v: string) => setForm({ ...form, [k]: v });

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  const next = () => step < steps.length - 1 ? setStep(step + 1) : finish();
  const back = () => setStep(Math.max(0, step - 1));

  const finish = async () => {
    if (!user) return;
    setSaving(true);
    const payload = {
      owner_id: user.id,
      bride_name: form.bride_name || "כלה",
      groom_name: form.groom_name || "חתן",
      event_date: form.event_date ? new Date(form.event_date).toISOString() : new Date(Date.now() + 1000*60*60*24*180).toISOString(),
      reception_time: form.reception_time,
      chuppah_time: form.chuppah_time,
      dress_code: form.dress_code,
      venue_name: form.venue_name,
      venue_address: form.venue_address,
      contact_bride: form.contact_bride,
      waze_url: form.venue_address ? `https://waze.com/ul?q=${encodeURIComponent(form.venue_address)}` : null,
      maps_url: form.venue_address ? `https://maps.google.com/?q=${encodeURIComponent(form.venue_address)}` : null,
    };
    const { error } = await supabase.from("events").insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success("האירוע נוצר! 💛");
    navigate("/dashboard");
  };

  return (
    <main className="min-h-screen flex items-center justify-center p-4">
      <Card className="glass-card p-8 w-full max-w-lg animate-scale-in">
        <div className="text-center mb-6">
          <div className="mx-auto h-12 w-12 rounded-full bg-gradient-gold flex items-center justify-center shadow-glow mb-3"><Heart className="h-5 w-5 text-primary-foreground" /></div>
          <h1 className="font-display text-3xl text-primary-deep">יוצרים את החתונה שלכם</h1>
          <p className="text-sm text-muted-foreground mt-2">שלב {step + 1} מתוך {steps.length} · {steps[step]}</p>
          <Progress value={((step + 1) / steps.length) * 100} className="mt-4 h-2" />
        </div>

        <div className="space-y-4 min-h-[220px]">
          {step === 0 && (<>
            <div><Label>שם הכלה</Label><Input placeholder="נועה" value={form.bride_name} onChange={(e) => set("bride_name", e.target.value)} className="mt-1" /></div>
            <div><Label>שם החתן</Label><Input placeholder="איתי" value={form.groom_name} onChange={(e) => set("groom_name", e.target.value)} className="mt-1" /></div>
          </>)}
          {step === 1 && (<>
            <div><Label>תאריך החתונה</Label><Input type="date" value={form.event_date} onChange={(e) => set("event_date", e.target.value)} className="mt-1" dir="ltr" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>קבלת פנים</Label><Input type="time" value={form.reception_time} onChange={(e) => set("reception_time", e.target.value)} className="mt-1" dir="ltr" /></div>
              <div><Label>חופה</Label><Input type="time" value={form.chuppah_time} onChange={(e) => set("chuppah_time", e.target.value)} className="mt-1" dir="ltr" /></div>
            </div>
            <div><Label>קוד לבוש</Label><Input placeholder="אלגנט בגווני שמנת" value={form.dress_code} onChange={(e) => set("dress_code", e.target.value)} className="mt-1" /></div>
          </>)}
          {step === 2 && (<>
            <div><Label>שם האולם</Label><Input placeholder="גני האחוזה" value={form.venue_name} onChange={(e) => set("venue_name", e.target.value)} className="mt-1" /></div>
            <div><Label>כתובת</Label><Input placeholder="דרך הים 1, ראשון לציון" value={form.venue_address} onChange={(e) => set("venue_address", e.target.value)} className="mt-1" /></div>
            <div><Label>טלפון ליצירת קשר</Label><Input type="tel" placeholder="052-1234567" value={form.contact_bride} onChange={(e) => set("contact_bride", e.target.value)} className="mt-1" dir="ltr" /></div>
          </>)}
          {step === 3 && (
            <div className="text-center py-8">
              <p className="font-script text-2xl text-primary mb-2">הכל מוכן 💛</p>
              <p className="text-muted-foreground">לחצו על "סיום" כדי להיכנס לדשבורד ולהזמין אורחים.</p>
            </div>
          )}
        </div>

        <div className="flex gap-2 mt-6">
          <Button variant="outlineGold" onClick={back} disabled={step === 0 || saving} className="flex-1"><ArrowRight className="h-4 w-4 ml-1" /> חזרה</Button>
          <Button variant="hero" onClick={next} disabled={saving} className="flex-1">{saving ? "שומר..." : step === steps.length - 1 ? "סיום" : "המשך"} <ArrowLeft className="h-4 w-4 mr-1" /></Button>
        </div>
      </Card>
    </main>
  );
};

export default Onboarding;
